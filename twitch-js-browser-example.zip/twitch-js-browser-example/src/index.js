// import "./styles.css";

// Provide your token, username and channel. You can generate a token here:
// https://twitchtokengenerator.com
const username = undefined;
const token = undefined;
const channel = "summit1g";

const { Chat } = window.TwitchJs;

const app = document.getElementById("app");
let x = document.createElement("INPUT");
x.setAttribute("type", "checkbox");
document.body.appendChild(x);

app.innerHTML = `<h1>TopChat</h1>`;

const chatDiv = document.getElementById("chat");

let chatters = [];
let chatMessage = [];


const run = async () => {
  const chat = new Chat({
    username,
    token,
    log: { level: "warn" }
  });

  chat.on("*", (message) => {
  
  
    let sub = message.tags.badgeInfo;

    function splitBadge(){
      if (sub != ""){
      sub = sub.split(",").map(sub => sub.split('/'));
      for (i = 0; i < sub.length; i++){
        let subCheck = sub[i]
        if (subCheck[0] == "subscriber"){
            subNum = subCheck[1];
             
        } else {
          subNum = 0;  
        }
      }
    } else {
    subNum = 0;
    }
  }
splitBadge()


    if (!chatters.some(chatter => chatter.id === message.tags.userId)) {
      chatters.push({
        id: message.tags.userId,
        dispName: message.tags.displayName,
        color: message.tags.color,
        gift: message.tags.badges.subGifter,
        subLength: subNum,
        mod: message.tags.mod
      })
      }

      // if(message.event != "PRIVMSG"){

      // console.log(chatMessage)

    // }

if(message.event == "PRIVMSG"){
  chatMessage.push({
    id: message.tags.userId,
    event: message.event,
    msgTime: message.timestamp.toJSON(),
    msg: message.message,
    msgLength: message.message.length
  })
}
 
let subscribed = [];
let gifted = [];
let mod = [];

function filterBy(filter, array, x){
  for (i = 0; i < chatters.length; i++){
    if (chatters[i][filter] > x){
      array.push(chatters[i].id)
    }
  }
}
// if (filtersub ==1){
  filterBy('subLength', subscribed, 20);
// }
filterBy('gift', gifted, 5);

filterBy('mod', mod, 0);

console.log(mod)



function filterIdList(arr1, arr2){
  let filterIds = []
  filterIds = new Set(filterIds.concat(arr1, arr2));
}

filterIdList()









  // message.event "CHEER"
// message.tags.bits
    
    const time = new Date(message.timestamp).toTimeString();
    const event = message.event || message.command;
    const channel = message.channel;
    const msg = message.message || "";
    const name = message.tags.displayName;
    //const receiver = message.parameters.recipientDisplayName;
    const color = message.tags.color;
    // const gifted = message.tags.badges.subGifter;
    const subscription = message.event;

      // if (message.tags.mod == 1){
          if (name != undefined){
            app.innerHTML +=`<div><span style="color: ${color}">${name}</span> : ${msg}</div>`;
          } 

      //message.event == "SUBSCRIPTION" || message.event == "RESUBSCRIPTION"  || message.event == "SUBSCRIPTION_GIFT"
  });

  await chat.connect();
  await chat.join(channel);
};

run();
