// import "./styles.css";

// Provide your token, username and channel. You can generate a token here:
// https://twitchtokengenerator.com
const username = undefined;
const token = undefined;
const channel = "drlupo";

const { Chat } = window.TwitchJs;

const app = document.getElementById("app");

app.innerHTML = `<h1>TopChat</h1>`;

const appMessage = document.createElement('div');
app.appendChild(appMessage);

const chatDiv = document.getElementById("chat");

let chatters = {};
let chatMessage = []; 
let subscribed = [];
let gifted = [];
let mod = [];

const run = async () => {
  const chat = new Chat({
    username,
    token,
    log: { level: "warn" }
  });

  chat.on("*", (message) => {

    splitBadge(message);

    newChatter(chatters, message);

    newPrivateMessage(chatMessage, message);
    // if(message.event != "PRIVMSG"){

    // if (filtersub == 1){
    filterBy('subLength', subscribed, 1);
    // }
    filterBy('gift', gifted, 5);

    filterBy('mod', mod, 0);

    console.log(subscribed)

    filterIdList()

    appendMessage(message);


    // message.event "CHEER"
    // message.tags.bits
    // const time = new Date(message.timestamp).toTimeString();
    // const event = message.event || message.command;
    // const channel = message.channel;
    // const msg = message.message || "";
    // const name = message.tags.displayName;
    // const receiver = message.parameters.recipientDisplayName;
    // const color = message.tags.color;
    // const gifted = message.tags.badges.subGifter;
    // const subscription = message.event;
    // message.event == "SUBSCRIPTION" || message.event == "RESUBSCRIPTION"  || message.event == "SUBSCRIPTION_GIFT"
  })
  await chat.connect();
  await chat.join(channel);
};

run();
