function splitBadge(message) {
    let sub = message.tags.badgeInfo;
    if (sub != "") {
        sub = sub.split(",").map(sub => sub.split('/'));
        for (i = 0; i < sub.length; i++) {
            let subCheck = sub[i]
            if (subCheck[0] == "subscriber") {
                subNum = subCheck[1];
            } else {
                subNum = 0; return
            }
        }
    } else {
        subNum = 0; return
    }
}

function newChatter(chatters, message) {
    if (!chatters[message.tags.userId]) {
        chatters[message.tags.userId] = {
            id: message.tags.userId,
            dispName: message.tags.displayName,
            color: message.tags.color,
            gift: message.tags.badges.subGifter,
            subLength: subNum,
            mod: message.tags.mod
        }; return
    }
}

function newPrivateMessage(chatMessage, message) {
    if (message.event == "PRIVMSG") {
        chatMessage.push({
            id: message.tags.userId,
            dispName: message.tags.displayName,
            event: message.event,
            msgTime: message.timestamp.toJSON(),
            msg: message.message,
            msgLength: message.message.length
        }); return
    }
}

function filterBy(filter, array, x) {
    for (let userId in chatters) {
        if (chatters[userId][filter] > x) {
            array.push(chatters[userId].id); return
        }
    }
}

function filterIdList(...args) {
    let filterIds = []
    filterIds = new Set(filterIds.concat(...args)); return
}

function appendMessage(message) {
    if (message.tags.displayName != undefined) {
        const appMessage = document.createElement('div');
        const nameSpan = document.createElement('span');
        const messageText = document.createElement('span');

        app.appendChild(appMessage)

        nameSpan.innerText = message.tags.displayName;
        nameSpan.style.color = message.tags.color;
        appMessage.appendChild(nameSpan);

        messageText.innerText = ': ' + message.message || "";
        appMessage.appendChild(messageText); return
    }
};